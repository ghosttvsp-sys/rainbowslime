package com.example.rainbowslime;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.MobEffects;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.potion.PotionEffect;

public class ItemRainbowSword extends ItemSword {
    public ItemRainbowSword() {
        super(ModItems.RAINBOW);
        setRegistryName(RainbowSlimeMod.MODID, "rainbow_sword");
        setUnlocalizedName(RainbowSlimeMod.MODID + ".rainbow_sword");
        setCreativeTab(CreativeTabs.COMBAT);
    }

    @Override
    public EnumRarity getRarity(ItemStack stack) {
        return EnumRarity.EPIC;
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        return true; // brilho de encantamento
    }

    @Override
    public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        target.addPotionEffect(new PotionEffect(MobEffects.GLOWING, 100));
        return super.hitEntity(stack, target, attacker);
    }
}
