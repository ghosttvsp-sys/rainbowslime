package com.example.rainbowslime;

import net.minecraft.entity.EnumCreatureType;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.common.registry.ForgeRegistries;

@Mod(modid = RainbowSlimeMod.MODID, name = "Rainbow Slime", version = "1.0.0",
        acceptedMinecraftVersions = "[1.12.2]")
public class RainbowSlimeMod {
    public static final String MODID = "rainbowslime";

    @Mod.Instance(MODID)
    public static RainbowSlimeMod instance;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        EntityRegistry.registerModEntity(
                new ResourceLocation(MODID, "rainbow_slime"),
                EntityRainbowSlime.class, "rainbow_slime", 0, instance,
                64, 3, true, 0xFF66CC, 0x66CCFF);

        // Spawna em todos os biomas, menos Nether e End. Peso baixo = raro.
        Biome[] biomes = ForgeRegistries.BIOMES.getValuesCollection().stream()
                .filter(b -> !BiomeDictionary.hasType(b, BiomeDictionary.Type.NETHER)
                          && !BiomeDictionary.hasType(b, BiomeDictionary.Type.END))
                .toArray(Biome[]::new);
        EntityRegistry.addSpawn(EntityRainbowSlime.class, 3, 1, 1, EnumCreatureType.MONSTER, biomes);
    }
}
