package com.example.rainbowslime;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Modelo humanoide da garota slime (textura 128x64). Corpo e cabelo mudam de cor sozinhos. */
@SideOnly(Side.CLIENT)
public class ModelSlimeGirl extends ModelBase {
    private final ModelRenderer head, body, armR, armL, legR, legL;
    private final ModelRenderer hairHead, hairBody, skirt;

    public ModelSlimeGirl() {
        this.textureWidth = 128;
        this.textureHeight = 64;

        head = new ModelRenderer(this, 0, 0);
        head.addBox(-4F, -8F, -4F, 8, 8, 8);
        head.setRotationPoint(0F, 4F, 0F);

        body = new ModelRenderer(this, 16, 16);
        body.addBox(-3F, 0F, -2F, 6, 9, 4);
        body.setRotationPoint(0F, 4F, 0F);

        armR = new ModelRenderer(this, 40, 16);
        armR.addBox(-1.5F, -1F, -1.5F, 3, 10, 3);
        armR.setRotationPoint(-4.5F, 5F, 0F);

        armL = new ModelRenderer(this, 32, 48);
        armL.mirror = true;
        armL.addBox(-1.5F, -1F, -1.5F, 3, 10, 3);
        armL.setRotationPoint(4.5F, 5F, 0F);

        legR = new ModelRenderer(this, 0, 16);
        legR.addBox(-1.5F, 0F, -1.5F, 3, 11, 3);
        legR.setRotationPoint(-1.8F, 13F, 0F);

        legL = new ModelRenderer(this, 16, 48);
        legL.mirror = true;
        legL.addBox(-1.5F, 0F, -1.5F, 3, 11, 3);
        legL.setRotationPoint(1.8F, 13F, 0F);

        // Cabelo da cabeça (grupo separado pra ter outra cor)
        hairHead = new ModelRenderer(this);
        hairHead.setRotationPoint(0F, 4F, 0F);
        addHair(hairHead, 64, 0, -4.5F, -8.5F, -4.5F, 9, 1, 9);   // topo
        addHair(hairHead, 64, 12, -4.5F, -8.5F, -4.5F, 9, 3, 1);  // franja
        addHair(hairHead, 64, 16, -4.5F, -8.5F, 3.5F, 9, 9, 2);   // nuca
        addHair(hairHead, 64, 28, 4F, -8F, -4F, 1, 6, 8);         // mecha esquerda
        addHair(hairHead, 64, 42, -5F, -8F, -4F, 1, 6, 8);        // mecha direita
        addHair(hairHead, 96, 16, -1F, -10F, -1F, 2, 2, 2);       // gotinha de slime no topo

        // Cabelo longo nas costas
        hairBody = new ModelRenderer(this);
        hairBody.setRotationPoint(0F, 4F, 0F);
        addHair(hairBody, 96, 0, -4F, 0F, 2F, 8, 13, 2);

        // Saia
        skirt = new ModelRenderer(this);
        skirt.setRotationPoint(0F, 11F, 0F);
        addHair(skirt, 96, 24, -4.5F, 0F, -3F, 9, 5, 6);
    }

    private void addHair(ModelRenderer parent, int u, int v, float x, float y, float z, int w, int h, int d) {
        ModelRenderer part = new ModelRenderer(this, u, v);
        part.addBox(x, y, z, w, h, d);
        parent.addChild(part);
    }

    private static void tint(float hue, float sat, float alpha) {
        int rgb = MathHelper.hsvToRGB(hue - (float) Math.floor(hue), sat, 1.0F);
        GlStateManager.color(((rgb >> 16) & 255) / 255F, ((rgb >> 8) & 255) / 255F, (rgb & 255) / 255F, alpha);
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                       float netHeadYaw, float headPitch, float scale) {
        this.setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entity);

        float t = ageInTicks / 140F + entity.getEntityId() * 0.17F;

        // Corpo: cor do arco-íris, translúcido
        tint(t, 0.45F, 0.85F);
        head.render(scale);
        body.render(scale);
        armR.render(scale);
        armL.render(scale);
        legR.render(scale);
        legL.render(scale);

        // Saia: matiz levemente deslocado
        tint(t + 0.12F, 0.65F, 0.9F);
        skirt.render(scale);

        // Cabelo: matiz oposto, mais forte
        tint(t + 0.5F, 0.75F, 0.95F);
        hairHead.render(scale);
        hairBody.render(scale);

        GlStateManager.color(1F, 1F, 1F, 1F);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch, float scaleFactor, Entity entity) {
        float rad = 0.017453292F;
        head.rotateAngleY = netHeadYaw * rad;
        head.rotateAngleX = headPitch * rad;
        hairHead.rotateAngleY = head.rotateAngleY;
        hairHead.rotateAngleX = head.rotateAngleX;

        float swing = limbSwing * 0.6662F;
        armR.rotateAngleX = MathHelper.cos(swing + (float) Math.PI) * 1.4F * limbSwingAmount * 0.5F;
        armL.rotateAngleX = MathHelper.cos(swing) * 1.4F * limbSwingAmount * 0.5F;
        legR.rotateAngleX = MathHelper.cos(swing) * 1.4F * limbSwingAmount;
        legL.rotateAngleX = MathHelper.cos(swing + (float) Math.PI) * 1.4F * limbSwingAmount;

        float idle = MathHelper.cos(ageInTicks * 0.09F) * 0.05F + 0.05F;
        armR.rotateAngleZ = idle;
        armL.rotateAngleZ = -idle;

        // Ataque: braços balançam pra frente
        if (this.swingProgress > 0F) {
            float s = MathHelper.sin(this.swingProgress * (float) Math.PI);
            armR.rotateAngleX = -s * 1.6F;
            armL.rotateAngleX = -s * 1.6F;
        }

        // Cabelo balança com o vento e com a caminhada
        hairBody.rotateAngleX = 0.05F + MathHelper.sin(ageInTicks * 0.08F) * 0.04F + limbSwingAmount * 0.35F;
    }
}
