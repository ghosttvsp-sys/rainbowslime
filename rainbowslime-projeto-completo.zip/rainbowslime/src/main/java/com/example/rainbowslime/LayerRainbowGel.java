package com.example.rainbowslime;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelSlime;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderSlime;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Cópia da camada de gel do slime, só que com cor mudando em arco-íris. */
@SideOnly(Side.CLIENT)
public class LayerRainbowGel implements LayerRenderer<EntitySlime> {
    private final RenderSlime renderer;
    private final ModelBase gelModel = new ModelSlime(0);

    public LayerRainbowGel(RenderSlime renderer) {
        this.renderer = renderer;
    }

    @Override
    public void doRenderLayer(EntitySlime slime, float limbSwing, float limbSwingAmount,
                              float partialTicks, float ageInTicks, float netHeadYaw,
                              float headPitch, float scale) {
        if (slime.isInvisible()) return;

        float hue = ((slime.ticksExisted + partialTicks) / 120.0F + slime.getEntityId() * 0.13F) % 1.0F;
        int rgb = MathHelper.hsvToRGB(hue, 0.65F, 1.0F);
        GlStateManager.color(((rgb >> 16) & 255) / 255F, ((rgb >> 8) & 255) / 255F, (rgb & 255) / 255F, 1.0F);

        GlStateManager.enableNormalize();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA,
                GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        this.gelModel.setModelAttributes(this.renderer.getMainModel());
        this.gelModel.setLivingAnimations(slime, limbSwing, limbSwingAmount, partialTicks);
        this.gelModel.render(slime, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
        GlStateManager.disableBlend();
        GlStateManager.disableNormalize();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    }

    @Override
    public boolean shouldCombineTextures() {
        return true;
    }
}
