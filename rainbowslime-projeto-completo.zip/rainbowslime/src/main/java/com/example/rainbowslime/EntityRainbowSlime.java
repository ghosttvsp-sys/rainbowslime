package com.example.rainbowslime;

import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

public class EntityRainbowSlime extends EntitySlime {
    /** Chance base de dropar a espada (0.03 = 3%) por slime pequeno morto. */
    private static final float DROP_CHANCE = 0.03F;
    /** Chance extra por nível de Saque (Looting). */
    private static final float LOOTING_BONUS = 0.01F;

    public EntityRainbowSlime(World world) {
        super(world);
    }

    // Os filhotes que nascem ao dividir também são arco-íris
    @Override
    protected EntitySlime createInstance() {
        return new EntityRainbowSlime(this.world);
    }

    @Override
    protected void dropFewItems(boolean wasRecentlyHit, int lootingModifier) {
        super.dropFewItems(wasRecentlyHit, lootingModifier);
        if (wasRecentlyHit && getSlimeSize() == 1) {
            float chance = DROP_CHANCE + lootingModifier * LOOTING_BONUS;
            if (this.rand.nextFloat() < chance) {
                this.dropItem(ModItems.RAINBOW_SWORD, 1);
            }
        }
    }

    // Spawn na superfície, sem depender de pântano/slime chunk
    @Override
    public boolean getCanSpawnHere() {
        return this.world.getDifficulty() != EnumDifficulty.PEACEFUL
                && this.world.canSeeSky(new BlockPos(this))
                && this.isNotColliding();
    }
}
