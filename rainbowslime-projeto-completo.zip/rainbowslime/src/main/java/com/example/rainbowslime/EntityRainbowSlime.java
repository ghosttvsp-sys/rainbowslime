package com.example.rainbowslime;

import net.minecraft.block.Block;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

/** Garota Slime Arco-Íris: neutra, só ataca se for atacada. */
public class EntityRainbowSlime extends EntityMob {
    /** Chance base de dropar a espada (0.05 = 5%). */
    private static final float DROP_CHANCE = 0.05F;
    /** Chance extra por nível de Saque (Looting). */
    private static final float LOOTING_BONUS = 0.02F;

    public EntityRainbowSlime(World world) {
        super(world);
        this.setSize(0.6F, 1.75F);
    }

    @Override
    protected void initEntityAI() {
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(1, new EntityAIAttackMelee(this, 1.0D, false));
        this.tasks.addTask(2, new EntityAIWanderAvoidWater(this, 0.8D));
        this.tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(4, new EntityAILookIdle(this));
        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(24.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.28D);
        this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(3.0D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(24.0D);
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_SLIME_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_SLIME_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, Block block) {
        this.playSound(SoundEvents.ENTITY_SLIME_SQUISH, 0.15F, 1.2F);
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.world.isRemote && this.rand.nextInt(12) == 0) {
            this.world.spawnParticle(EnumParticleTypes.SLIME,
                    this.posX + (this.rand.nextDouble() - 0.5D) * this.width,
                    this.posY + 0.1D + this.rand.nextDouble() * 0.6D,
                    this.posZ + (this.rand.nextDouble() - 0.5D) * this.width,
                    0.0D, 0.0D, 0.0D);
        }
    }

    @Override
    protected void dropFewItems(boolean wasRecentlyHit, int lootingModifier) {
        int balls = this.rand.nextInt(3 + lootingModifier);
        if (balls > 0) {
            this.dropItem(Items.SLIME_BALL, balls);
        }
        if (wasRecentlyHit) {
            float chance = DROP_CHANCE + lootingModifier * LOOTING_BONUS;
            if (this.rand.nextFloat() < chance) {
                this.dropItem(ModItems.RAINBOW_SWORD, 1);
            }
        }
    }

    // Spawna na superfície, de dia ou de noite
    @Override
    public boolean getCanSpawnHere() {
        return this.world.getDifficulty() != EnumDifficulty.PEACEFUL
                && this.world.canSeeSky(new BlockPos(this))
                && this.isNotColliding();
    }

    @Override
    public int getMaxSpawnedInChunk() {
        return 1;
    }
}
