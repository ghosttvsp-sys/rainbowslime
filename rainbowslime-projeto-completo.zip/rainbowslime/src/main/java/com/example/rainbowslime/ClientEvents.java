package com.example.rainbowslime;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = RainbowSlimeMod.MODID, value = Side.CLIENT)
public class ClientEvents {
    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation(ModItems.RAINBOW_SWORD, 0,
                new ModelResourceLocation(ModItems.RAINBOW_SWORD.getRegistryName(), "inventory"));
        RenderingRegistry.registerEntityRenderingHandler(EntityRainbowSlime.class, RenderRainbowSlime::new);
    }
}
