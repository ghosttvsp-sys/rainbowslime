package com.example.rainbowslime;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderRainbowSlime extends RenderLiving<EntityRainbowSlime> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(RainbowSlimeMod.MODID, "textures/entity/rainbow_slime_girl.png");

    public RenderRainbowSlime(RenderManager manager) {
        super(manager, new ModelSlimeGirl(), 0.4F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityRainbowSlime entity) {
        return TEXTURE;
    }

    @Override
    protected void renderModel(EntityRainbowSlime entity, float limbSwing, float limbSwingAmount,
                               float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor) {
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA,
                GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        super.renderModel(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor);
        GlStateManager.disableBlend();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    }
}
