package com.example.rainbowslime;

import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderSlime;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderRainbowSlime extends RenderSlime {
    public RenderRainbowSlime(RenderManager manager) {
        super(manager);
        this.layerRenderers.clear();           // remove o gel verde padrão
        this.addLayer(new LayerRainbowGel(this));
    }
}
