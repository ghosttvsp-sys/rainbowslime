package com.example.rainbowslime;

import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = RainbowSlimeMod.MODID)
public class ModItems {
    // harvestLevel, durabilidade, velocidade de mineração, dano base, encantabilidade
    // Dano final da espada = 3 + dano base (aqui 3 + 6 = 9)
    public static final ToolMaterial RAINBOW =
            EnumHelper.addToolMaterial("RAINBOW", 3, 2500, 9.0F, 6.0F, 25);

    public static final Item RAINBOW_SWORD = new ItemRainbowSword();

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().register(RAINBOW_SWORD);
    }
}
